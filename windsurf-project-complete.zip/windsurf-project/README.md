# TechHub - E-Commerce Platform

Une plateforme e-commerce moderne pour composants informatiques avec authentification complète et mode sombre.

## 🚀 Fonctionnalités

### ✅ Implémenté
- ✨ **Authentification complète** (Backend Node.js + MongoDB)
  - Login avec validation
  - Signup avec création de compte
  - Messages d'erreur pour mot de passe incorrect
  - Sessions utilisateur persistantes
  
- 🌙 **Dark Mode**
  - Toggle fonctionnel sur toutes les pages
  - Icône croissant de lune
  - Préférence sauvegardée (localStorage)
  
- 👤 **Gestion du Profil**
  - Icône profil visible uniquement si connecté
  - Boutons Login/Signup cachés après connexion
  - Redirection automatique vers page d'accueil après login
  - Affichage des données utilisateur dans le profil
  - Bouton Logout fonctionnel
  
- 🛍️ **E-Commerce**
  - 46 produits (processeurs, cartes graphiques, RAM, etc.)
  - Système de filtres et recherche
  - Panier d'achat
  - Pages détails produits

## 📋 Prérequis

- **Node.js** (v14 ou supérieur)
- **MongoDB** (v4.4 ou supérieur)
- **npm** ou **yarn**

## 🔧 Installation

### 1. Cloner le projet
```bash
cd windsurf-project
```

### 2. Installer MongoDB
#### Sur Windows:
- Télécharger MongoDB Community Server depuis [mongodb.com](https://www.mongodb.com/try/download/community)
- Installer et démarrer le service MongoDB

#### Sur macOS (Homebrew):
```bash
brew tap mongodb/brew
brew install mongodb-community
brew services start mongodb-community
```

#### Sur Linux (Ubuntu):
```bash
sudo apt-get install mongodb
sudo systemctl start mongodb
```

### 3. Installer les dépendances backend
```bash
cd backend
npm install
```

### 4. Initialiser la base de données
```bash
# Cette commande va créer les 4 utilisateurs de test
node seedUsers.js
```

Vous devriez voir:
```
✅ Connected to MongoDB
🗑️  Cleared existing users
✅ Successfully created 4 users:
   - Lyes (Lyes@gmail.com)
   - Jugo (Jugo@gmail.com)
   - Wassim (Wassim@gmail.com)
   - Mazigh (Mazigh@gmail.com)

📝 All users have password: Password123
```

## 🏃‍♂️ Démarrage

### 1. Démarrer le serveur backend
```bash
cd backend
npm start
```

Le serveur démarre sur `http://localhost:5000`

### 2. Démarrer le frontend
```bash
# Dans un nouveau terminal
cd frontend/public

# Avec Python 3:
python -m http.server 3000

# OU avec Python 2:
python -m SimpleHTTPServer 3000

# OU avec Node.js (si http-server est installé):
npx http-server -p 3000
```

Le frontend est accessible sur `http://localhost:3000`

### 3. Ouvrir dans le navigateur
Ouvrez votre navigateur et allez sur:
```
http://localhost:3000
```

## 👥 Comptes de Test

Vous pouvez vous connecter avec l'un de ces comptes :

| Nom    | Email              | Mot de passe  | Téléphone          | Ville         | Pays    |
|--------|-------------------|---------------|-------------------|---------------|---------|
| Lyes   | Lyes@gmail.com    | Password123   | +213 555 123 456  | Bab Ezzouar   | Algérie |
| Jugo   | Jugo@gmail.com    | Password123   | +213 555 234 567  | Alger Centre  | Algérie |
| Wassim | Wassim@gmail.com  | Password123   | +213 555 345 678  | Alger         | Algérie |
| Mazigh | Mazigh@gmail.com  | Password123   | +213 555 456 789  | Bab Ezzouar   | Algérie |

## 🎯 Utilisation

### Se connecter
1. Cliquez sur "Login" dans la navbar
2. Entrez un email (ex: `Lyes@gmail.com`)
3. Entrez le mot de passe: `Password123`
4. Cliquez sur "Login"

**Si le mot de passe est incorrect, vous verrez:** "Mot de passe incorrect."

### Créer un compte
1. Cliquez sur "Sign Up"
2. Remplissez le formulaire
3. Créez votre compte
4. Vous serez automatiquement connecté et redirigé

### Accéder au profil
1. Une fois connecté, l'icône profil (👤) apparaît dans la navbar
2. Cliquez dessus pour voir votre profil
3. Vos informations personnelles s'affichent
4. Bouton "Logout" disponible pour se déconnecter

### Activer le Dark Mode
1. Cliquez sur l'icône croissant de lune (🌙) dans la navbar
2. Le thème change instantanément
3. Votre préférence est sauvegardée

## 🗂️ Structure du Projet

```
windsurf-project/
├── backend/                    # Serveur Node.js
│   ├── models/
│   │   └── User.js            # Modèle utilisateur MongoDB
│   ├── routes/
│   │   └── auth.js            # Routes d'authentification
│   ├── server.js              # Serveur Express principal
│   ├── seedUsers.js           # Script d'initialisation DB
│   ├── package.json
│   └── .env                   # Configuration
│
└── frontend/
    └── public/
        ├── index.html         # Page d'accueil
        ├── login.html         # Page login
        ├── signup.html        # Page inscription
        ├── profile.html       # Page profil
        ├── product-details.html
        │
        ├── css/
        │   ├── main.css
        │   ├── darkmode.css   # 🆕 Styles dark mode
        │   └── ...
        │
        └── js/
            ├── auth.js        # 🆕 Gestion authentification
            ├── navbar.js      # 🆕 Navbar dynamique + dark mode
            ├── profile.js     # 🆕 Gestion page profil
            └── ...
```

## 🔐 API Endpoints

### Authentification
- `POST /api/auth/login` - Connexion utilisateur
- `POST /api/auth/signup` - Création de compte
- `POST /api/auth/logout` - Déconnexion
- `GET /api/auth/check-session` - Vérifier session
- `GET /api/auth/profile` - Obtenir profil utilisateur

## 🎨 Thèmes

### Light Mode (Par défaut)
- Fond blanc (#ffffff)
- Texte noir (#212529)
- Interface claire et moderne

### Dark Mode
- Fond sombre (#1a1a1a)
- Texte clair (#f8f9fa)
- Réduit la fatigue oculaire

## 🛠️ Technologies Utilisées

### Backend
- **Node.js** - Runtime JavaScript
- **Express** - Framework web
- **MongoDB** - Base de données NoSQL
- **Mongoose** - ODM pour MongoDB
- **express-session** - Gestion des sessions

### Frontend
- **HTML5** - Structure
- **CSS3** - Styling (avec variables CSS pour dark mode)
- **JavaScript Vanilla** - Logique
- **Font Awesome 6** - Icônes

## 📝 Notes Importantes

1. **Pas de hashage de mot de passe** - Comme demandé, les mots de passe sont stockés en clair (⚠️ NE PAS utiliser en production)
2. **Sessions** - Les sessions utilisateur expirent après 24 heures
3. **CORS** - Configuré pour accepter les requêtes de `localhost:3000`
4. **LocalStorage** - Stocke les infos utilisateur côté client pour persistance

## 🐛 Dépannage

### Le backend ne démarre pas
- Vérifiez que MongoDB est en cours d'exécution
- Vérifiez le fichier `.env` dans le dossier backend
- Assurez-vous que le port 5000 est libre

### Le frontend ne se connecte pas au backend
- Vérifiez que le backend est démarré sur le port 5000
- Vérifiez la console du navigateur pour les erreurs CORS
- Assurez-vous que l'URL du frontend est `http://localhost:3000`

### Les données utilisateur ne s'affichent pas
- Vérifiez la console du navigateur (F12)
- Assurez-vous d'être connecté
- Vérifiez que le localStorage contient les données utilisateur

### Dark mode ne fonctionne pas
- Videz le cache du navigateur (Ctrl+Shift+R)
- Vérifiez que `darkmode.css` est chargé
- Ouvrez la console pour voir les erreurs

## 📧 Support

Pour toute question ou problème, consultez les logs:
- Backend: Terminal où `npm start` est exécuté
- Frontend: Console du navigateur (F12)

## 🎉 Fonctionnalités Futures Possibles

- [ ] Système de paiement (Stripe/PayPal)
- [ ] Historique des commandes
- [ ] Système de wishlist
- [ ] Comparateur de produits
- [ ] Notifications en temps réel
- [ ] Panel administrateur
- [ ] Reset de mot de passe
- [ ] Hashage des mots de passe (bcrypt)
- [ ] Upload d'avatar utilisateur

---

**Développé avec ❤️ pour TechHub**
