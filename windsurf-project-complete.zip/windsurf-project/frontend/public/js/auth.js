// API Base URL
const API_URL = 'http://localhost:5000/api';

// Login Form Handler
document.getElementById('loginForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    
    try {
        const response = await fetch(`${API_URL}/auth/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            credentials: 'include', // Important for sessions
            body: JSON.stringify({ email, password })
        });
        
        const data = await response.json();
        
        if (data.success) {
            // Save user info to localStorage
            localStorage.setItem('user', JSON.stringify(data.user));
            localStorage.setItem('isLoggedIn', 'true');
            
            // Show success message
            alert(data.message);
            
            // Redirect to home page
            window.location.href = 'index.html';
        } else {
            // Show error message
            alert(data.message);
        }
        
    } catch (error) {
        console.error('Login error:', error);
        alert('Erreur de connexion au serveur. Veuillez réessayer.');
    }
});

// Signup Form Handler
document.getElementById('signupForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword')?.value;
    
    // Check if passwords match
    if (confirmPassword && password !== confirmPassword) {
        alert('Les mots de passe ne correspondent pas.');
        return;
    }
    
    try {
        const response = await fetch(`${API_URL}/auth/signup`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            credentials: 'include',
            body: JSON.stringify({ name, email, password })
        });
        
        const data = await response.json();
        
        if (data.success) {
            // Save user info to localStorage
            localStorage.setItem('user', JSON.stringify(data.user));
            localStorage.setItem('isLoggedIn', 'true');
            
            // Show success message
            alert(data.message);
            
            // Redirect to home page
            window.location.href = 'index.html';
        } else {
            // Show error message
            alert(data.message);
        }
        
    } catch (error) {
        console.error('Signup error:', error);
        alert('Erreur de connexion au serveur. Veuillez réessayer.');
    }
});

// Logout Handler
async function logout() {
    try {
        await fetch(`${API_URL}/auth/logout`, {
            method: 'POST',
            credentials: 'include'
        });
        
        // Clear local storage
        localStorage.removeItem('user');
        localStorage.removeItem('isLoggedIn');
        
        // Redirect to home
        window.location.href = 'index.html';
        
    } catch (error) {
        console.error('Logout error:', error);
    }
}

// Check authentication status on page load
async function checkAuthStatus() {
    const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
    const user = JSON.parse(localStorage.getItem('user'));
    
    return { isLoggedIn, user };
}
