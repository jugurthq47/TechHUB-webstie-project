// Dark Mode Toggle
function initDarkMode() {
    // Check saved preference or default to light mode
    const savedTheme = localStorage.getItem('theme') || 'light';
    document.documentElement.setAttribute('data-theme', savedTheme);
    
    // Update toggle button if it exists
    const darkModeToggle = document.getElementById('darkModeToggle');
    if (darkModeToggle) {
        darkModeToggle.innerHTML = savedTheme === 'dark' 
            ? '<i class="fas fa-sun"></i>' 
            : '<i class="fas fa-moon"></i>';
    }
}

// Toggle dark mode
function toggleDarkMode() {
    const currentTheme = document.documentElement.getAttribute('data-theme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);
    
    // Update toggle button icon
    const darkModeToggle = document.getElementById('darkModeToggle');
    if (darkModeToggle) {
        darkModeToggle.innerHTML = newTheme === 'dark' 
            ? '<i class="fas fa-sun"></i>' 
            : '<i class="fas fa-moon"></i>';
    }
}

// Update Navbar based on authentication status
async function updateNavbar() {
    const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
    const user = JSON.parse(localStorage.getItem('user'));
    
    const authButtons = document.querySelector('.auth-buttons');
    const profileIcon = document.querySelector('.profile-icon');
    
    if (isLoggedIn && user) {
        // Hide login/signup buttons
        if (authButtons) {
            authButtons.style.display = 'none';
        }
        
        // Show profile icon
        if (profileIcon) {
            profileIcon.style.display = 'flex';
            profileIcon.style.cursor = 'pointer';
            
            // Add click handler to redirect to profile
            profileIcon.onclick = () => {
                window.location.href = 'profile.html';
            };
        }
    } else {
        // Show login/signup buttons
        if (authButtons) {
            authButtons.style.display = 'flex';
        }
        
        // Hide profile icon
        if (profileIcon) {
            profileIcon.style.display = 'none';
        }
    }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    initDarkMode();
    updateNavbar();
    
    // Add dark mode toggle event listener
    const darkModeToggle = document.getElementById('darkModeToggle');
    if (darkModeToggle) {
        darkModeToggle.addEventListener('click', toggleDarkMode);
    }
});
