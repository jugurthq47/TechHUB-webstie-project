// Profile Page Script
const API_URL = 'http://localhost:5000/api';

// Check if user is logged in
async function checkProfileAuth() {
    const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
    const user = JSON.parse(localStorage.getItem('user'));
    
    if (!isLoggedIn || !user) {
        // Redirect to login if not authenticated
        alert('Veuillez vous connecter pour accéder à votre profil.');
        window.location.href = 'login.html';
        return;
    }
    
    // Load user data
    loadUserProfile(user);
}

// Load user profile data
function loadUserProfile(user) {
    // Update profile information
    document.getElementById('profileName').textContent = user.name || 'N/A';
    document.getElementById('profileEmail').textContent = user.email || 'N/A';
    document.getElementById('profilePhone').textContent = user.phone || 'Not provided';
    document.getElementById('profileCity').textContent = user.city || 'Not specified';
    document.getElementById('profileCountry').textContent = user.country || 'Not specified';
}

// Add logout button functionality
function addLogoutButton() {
    const profileHeader = document.querySelector('.profile-header');
    
    if (profileHeader && !document.getElementById('logoutBtn')) {
        const logoutBtn = document.createElement('button');
        logoutBtn.id = 'logoutBtn';
        logoutBtn.className = 'logout-btn';
        logoutBtn.innerHTML = '<i class="fas fa-sign-out-alt"></i> Logout';
        logoutBtn.style.cssText = `
            background: #dc3545;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            margin-top: 15px;
            transition: background 0.3s ease;
        `;
        
        logoutBtn.addEventListener('mouseenter', () => {
            logoutBtn.style.background = '#c82333';
        });
        
        logoutBtn.addEventListener('mouseleave', () => {
            logoutBtn.style.background = '#dc3545';
        });
        
        logoutBtn.addEventListener('click', async () => {
            try {
                await fetch(`${API_URL}/auth/logout`, {
                    method: 'POST',
                    credentials: 'include'
                });
            } catch (error) {
                console.error('Logout error:', error);
            }
            
            // Clear local storage
            localStorage.removeItem('user');
            localStorage.removeItem('isLoggedIn');
            
            // Redirect to home
            window.location.href = 'index.html';
        });
        
        const profileInfo = document.querySelector('.profile-info');
        if (profileInfo) {
            profileInfo.appendChild(logoutBtn);
        }
    }
}

// Initialize profile page
document.addEventListener('DOMContentLoaded', () => {
    checkProfileAuth();
    addLogoutButton();
});
