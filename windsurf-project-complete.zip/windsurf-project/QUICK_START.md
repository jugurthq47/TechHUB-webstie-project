# 🚀 Guide de Démarrage Rapide - TechHub

## Installation en 5 minutes

### 1️⃣ Installer MongoDB
**Windows:** Téléchargez depuis https://www.mongodb.com/try/download/community
**Mac:** `brew install mongodb-community && brew services start mongodb-community`
**Linux:** `sudo apt-get install mongodb && sudo systemctl start mongodb`

### 2️⃣ Installer les dépendances
```bash
cd backend
npm install
```

### 3️⃣ Créer les utilisateurs de test
```bash
cd backend
node seedUsers.js
```

### 4️⃣ Démarrer le backend
```bash
cd backend
npm start
```
✅ Backend running on http://localhost:5000

### 5️⃣ Démarrer le frontend (nouveau terminal)
```bash
cd frontend/public
python -m http.server 3000
```
✅ Frontend running on http://localhost:3000

### 6️⃣ Ouvrir le navigateur
Aller sur: **http://localhost:3000**

---

## 👤 Se connecter

**Email:** `Lyes@gmail.com`
**Mot de passe:** `Password123`

Ou utilisez: Jugo@gmail.com, Wassim@gmail.com, Mazigh@gmail.com

---

## ✨ Tester les fonctionnalités

### ✅ Dark Mode
Cliquez sur l'icône 🌙 dans la navbar

### ✅ Login
1. Cliquez "Login"
2. Entrez: `Lyes@gmail.com` / `Password123`
3. Vous êtes redirigé vers l'accueil
4. L'icône profil 👤 apparaît

### ✅ Profil
1. Cliquez sur l'icône 👤
2. Voyez vos informations
3. Bouton "Logout" disponible

### ✅ Mot de passe incorrect
1. Login avec `Lyes@gmail.com` / `WrongPassword`
2. Message: "Mot de passe incorrect."

### ✅ Signup
1. Créez un nouveau compte
2. Connexion automatique après création

---

## 🛑 Arrêter les serveurs

**Backend:** `Ctrl + C` dans le terminal
**Frontend:** `Ctrl + C` dans le terminal

---

## 📞 Besoin d'aide?

Consultez le README.md complet pour plus de détails !
